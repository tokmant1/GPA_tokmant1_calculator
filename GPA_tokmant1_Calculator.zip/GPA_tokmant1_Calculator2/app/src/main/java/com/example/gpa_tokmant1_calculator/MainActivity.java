package com.example.gpa_tokmant1_calculator;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    View v;
    Button btn;
    EditText grade1, grade2, grade3, grade4, grade5;
    TextView t;
    int count = 0;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        v = this.getWindow().getDecorView();

        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.b);
        grade1 = findViewById(R.id.e1);
        grade2 = findViewById(R.id.e2);
        grade3 = findViewById(R.id.e3);
        grade4 = findViewById(R.id.e4);
        grade5 = findViewById(R.id.e5);
        t = findViewById(R.id.t);
        t.setBackgroundColor(Color.WHITE);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float g1, g2, g3, g4, g5;
                if (count % 2 == 0) {
                    if (grade1.getText().toString().equals("") || grade2.getText().toString().equals("") || grade3.getText().toString().equals("") || grade4.getText().toString().equals("") || grade5.getText().toString().equals("")) {
                        t.setText("All fields are required.");
                    } else {
                        g1 = Float.parseFloat(grade1.getText().toString());
                        g2 = Float.parseFloat(grade2.getText().toString());
                        g3 = Float.parseFloat(grade3.getText().toString());
                        g4 = Float.parseFloat(grade4.getText().toString());
                        g5 = Float.parseFloat(grade5.getText().toString());
                        float avg = g1 + g2 + g3 + g4 + g5;
                        avg = (avg / 5);

                            if (avg < 60) {
                                t.setText(Float.toString(avg));
                                v.setBackgroundResource(R.color.red);
                            } else if (avg > 60 && avg < 80) {
                                t.setText(Float.toString(avg));
                                v.setBackgroundResource(R.color.yellow);
                            } else if (avg >= 80 && avg <= 100) {
                                t.setText(Float.toString(avg));
                                v.setBackgroundResource(R.color.green);
                            }

                        count++;
                        btn.setText("Clear");
                    }

                } else {
                    grade1.setText("");
                    grade2.setText("");
                    grade3.setText("");
                    grade4.setText("");
                    grade5.setText("");
                    t.setText("");
                    btn.setText("Compute GPA");
                    v.setBackgroundColor(Color.WHITE);
                    count++;
                }
            }
        });
    }
}